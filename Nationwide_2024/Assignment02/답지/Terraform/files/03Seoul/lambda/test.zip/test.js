const { timeStamp } = require("console");

timeStamp